const onResponse = (response) => {};

fetch(
  "https://europe-west1-javascript-lessons-tijl.cloudfunctions.net/plants/api/v1/plants"
)
  .then((res) => res.json())
  .then((res) => onResponse(res));
