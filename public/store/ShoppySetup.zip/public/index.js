const onResponse = (response) => {};

fetch("/products.json")
  .then((res) => res.json())
  .then((res) => onResponse(res));
